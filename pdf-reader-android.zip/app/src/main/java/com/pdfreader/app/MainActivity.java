package com.pdfreader.app;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.webkit.WebViewAssetLoader;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
  WebView wv;
  ValueCallback<Uri[]> fileCb;
  volatile Uri extUri;
  volatile String extName = "";
  static final int REQ = 1;

  class Bridge {
    @JavascriptInterface public void save(String name, String b64) { saveToDownloads(name, b64); }
    @JavascriptInterface public boolean hasExt() { return extUri != null; }
    @JavascriptInterface public String getExtName() { return extName; }
  }

  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    getWindow().setStatusBarColor(0xFF17171D);
    getWindow().setNavigationBarColor(0xFF17171D);
    wv = new WebView(this);
    setContentView(wv);
    WebSettings s = wv.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(false);
    final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
      .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
      .addPathHandler("/ext/", path -> {
        try {
          if (extUri == null) return null;
          InputStream in = getContentResolver().openInputStream(extUri);
          return new WebResourceResponse("application/pdf", null, in);
        } catch (Exception e) { return null; }
      }).build();
    wv.setWebViewClient(new WebViewClient() {
      @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
        return loader.shouldInterceptRequest(r.getUrl());
      }
    });
    wv.setWebChromeClient(new WebChromeClient() {
      @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
        if (fileCb != null) fileCb.onReceiveValue(null);
        fileCb = cb;
        try { startActivityForResult(p.createIntent(), REQ); }
        catch (Exception e) { fileCb = null; return false; }
        return true;
      }
    });
    wv.addJavascriptInterface(new Bridge(), "Android");
    handle(getIntent());
    wv.loadUrl("https://appassets.androidplatform.net/assets/index.html");
  }

  void handle(Intent i) {
    if (i != null && Intent.ACTION_VIEW.equals(i.getAction()) && i.getData() != null) {
      extUri = i.getData();
      extName = nameOf(extUri);
    }
  }

  String nameOf(Uri u) {
    try (Cursor c = getContentResolver().query(u, null, null, null, null)) {
      if (c != null && c.moveToFirst()) {
        int k = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
        if (k >= 0) return c.getString(k);
      }
    } catch (Exception e) { }
    String p = u.getLastPathSegment();
    return p == null ? "document.pdf" : p;
  }

  @Override protected void onNewIntent(Intent i) {
    super.onNewIntent(i);
    handle(i);
    wv.evaluateJavascript("window.openExt&&openExt()", null);
  }

  @Override protected void onActivityResult(int rq, int rs, Intent d) {
    if (rq == REQ && fileCb != null) {
      fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(rs, d));
      fileCb = null;
    } else super.onActivityResult(rq, rs, d);
  }

  @Override public void onBackPressed() {
    wv.evaluateJavascript("(function(){var s=document.getElementById('sbg');if(s&&!s.hidden){s.hidden=true;return 1}return 0})()",
      v -> { if (!"1".equals(v)) finish(); });
  }

  void toast(final String m) { runOnUiThread(() -> Toast.makeText(this, m, Toast.LENGTH_LONG).show()); }

  void saveToDownloads(String name, String b64) {
    try {
      byte[] by = Base64.decode(b64, Base64.DEFAULT);
      ContentValues v = new ContentValues();
      v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
      v.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
      v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
      Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
      OutputStream os = getContentResolver().openOutputStream(u);
      os.write(by);
      os.close();
      toast("ذخیره شد در Downloads: " + name);
    } catch (Exception e) { toast("ذخیره نشد"); }
  }
}
