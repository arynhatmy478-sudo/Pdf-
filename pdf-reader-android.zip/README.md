# PDF Reader (Android)
1. Push this folder to a new GitHub repo (branch `main`).
2. Open the **Actions** tab -> *Build APK* runs automatically (or run it manually).
3. Download the APK from the run's **Artifacts**, or from the repo's **Releases** page.
Debug-signed APK; enable "install unknown apps" on the phone. Min Android 10.
